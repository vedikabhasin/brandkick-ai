"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, RefreshCw, ExternalLink, Check, X } from "lucide-react"
import { generateNames } from "@/app/actions"

type DomainStatus = "available" | "unavailable" | "checking" | "idle"

interface NameResult {
  name: string
  domainStatus: DomainStatus
}

export default function StartupNameGenerator() {
  const [description, setDescription] = useState("")
  const [tone, setTone] = useState("modern")
  const [isGenerating, setIsGenerating] = useState(false)
  const [results, setResults] = useState<NameResult[]>([])

  const tones = [
    { id: "modern", label: "Modern" },
    { id: "vcbait", label: "VC Bait" },
    { id: "gritty", label: "Gritty" },
    { id: "elegant", label: "Elegant" },
    { id: "techy", label: "Techy" },
    { id: "playful", label: "Playful" },
  ]

  const handleGenerate = async () => {
    if (!description.trim()) return

    setIsGenerating(true)
    setResults([])

    try {
      const names = await generateNames(description, tone)
      const initialResults = names.map((name) => ({
        name,
        domainStatus: "idle" as DomainStatus,
      }))
      setResults(initialResults)

      // Check domain availability for each name
      for (let i = 0; i < initialResults.length; i++) {
        const result = { ...initialResults[i], domainStatus: "checking" as DomainStatus }
        setResults((prev) => [...prev.slice(0, i), result, ...prev.slice(i + 1)])

        try {
          const available = await checkDomainAvailability(initialResults[i].name)
          const updatedResult = {
            ...result,
            domainStatus: available ? "available" : ("unavailable" as DomainStatus),
          }
          setResults((prev) => [...prev.slice(0, i), updatedResult, ...prev.slice(i + 1)])
        } catch (error) {
          const updatedResult = { ...result, domainStatus: "idle" as DomainStatus }
          setResults((prev) => [...prev.slice(0, i), updatedResult, ...prev.slice(i + 1)])
        }
      }
    } catch (error) {
      console.error("Error generating names:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const checkDomainAvailability = async (name: string): Promise<boolean> => {
    // Simulate API call to check domain availability
    // In a real implementation, you would call the GoDaddy API or similar
    await new Promise((resolve) => setTimeout(resolve, 1000 + Math.random() * 1000))
    return Math.random() > 0.5 // Randomly return available or not for demo
  }

  const handleRegenerateNames = () => {
    handleGenerate()
  }

  const getDomainStatusIcon = (status: DomainStatus) => {
    switch (status) {
      case "available":
        return <Check className="h-4 w-4 text-green-500" />
      case "unavailable":
        return <X className="h-4 w-4 text-red-500" />
      case "checking":
        return <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
      default:
        return null
    }
  }

  const openDomainRegistrar = (name: string) => {
    window.open(`https://www.godaddy.com/domainsearch/find?domainToCheck=${name}.com`, "_blank")
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-2">Aesthetic Startup Name Generator</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Generate unique, memorable startup names with instant domain availability checking
        </p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Generate Your Startup Name</CardTitle>
          <CardDescription>Describe what your startup does and choose a tone</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <label htmlFor="description" className="block text-sm font-medium mb-2">
                What does your startup do?
              </label>
              <Input
                id="description"
                placeholder="e.g., AI-powered productivity tools for remote teams"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Choose a tone</label>
              <div className="flex flex-wrap gap-2">
                {tones.map((t) => (
                  <Badge
                    key={t.id}
                    variant={tone === t.id ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setTone(t.id)}
                  >
                    {t.label}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleGenerate} disabled={isGenerating || !description.trim()} className="w-full">
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Names"
            )}
          </Button>
        </CardFooter>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Generated Names</CardTitle>
              <CardDescription>Click on a name to check domain availability</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={handleRegenerateNames} disabled={isGenerating}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Regenerate
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {results.map((result, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="p-4 flex items-center justify-between">
                    <div className="font-medium text-lg">{result.name}</div>
                    <div className="flex items-center space-x-2">
                      {getDomainStatusIcon(result.domainStatus)}
                      <span className="text-sm">
                        {result.domainStatus === "available" && "Available"}
                        {result.domainStatus === "unavailable" && "Unavailable"}
                        {result.domainStatus === "checking" && "Checking..."}
                        {result.domainStatus === "idle" && ""}
                      </span>
                    </div>
                  </div>
                  <div className="bg-gray-50 p-3 flex justify-between items-center border-t">
                    <div className="text-sm text-gray-500">{result.name}.com</div>
                    <Button variant="ghost" size="sm" onClick={() => openDomainRegistrar(result.name)}>
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Check
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
