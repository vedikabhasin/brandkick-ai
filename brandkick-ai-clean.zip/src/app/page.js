'use client';
import { useState } from 'react';

export default function Home() {
  const vibes = ["Minimal", "Bold", "Playful", "Luxury", "Techy"];
  const [idea, setIdea] = useState('');
  const [vibe, setVibe] = useState(vibes[0]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  const generateNames = async () => {
    setLoading(true);
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: `Suggest 5 brand names with taglines for a startup idea: "${idea}". Style: ${vibe}. Format as: Name - Tagline.`
      })
    });
    const data = await res.json();
    const names = data.output?.split('\n').filter(line => line.includes('-')) || [];
    setResults(names);
    setLoading(false);
  };

  return (
    <main className="min-h-screen bg-black text-white px-6 py-10 flex flex-col items-center">
      <h1 className="text-4xl font-bold mb-2">BrandKick AI</h1>
      <p className="text-gray-400 mb-6 text-center">Generate aesthetic brand names + taglines fast.</p>

      <textarea
        value={idea}
        onChange={(e) => setIdea(e.target.value)}
        placeholder="Describe your startup idea..."
        className="w-full max-w-xl p-4 mb-4 rounded bg-gray-800 text-white border border-gray-600"
        rows={4}
      />

      <div className="mb-4">
        <label className="mr-2">Vibe:</label>
        <select
          value={vibe}
          onChange={(e) => setVibe(e.target.value)}
          className="bg-gray-800 text-white p-2 border border-gray-600 rounded"
        >
          {vibes.map(v => <option key={v}>{v}</option>)}
        </select>
      </div>

      <button
        onClick={generateNames}
        disabled={loading || !idea}
        className="bg-blue-600 hover:bg-blue-500 px-6 py-2 rounded text-white mb-6 disabled:opacity-50"
      >
        {loading ? 'Generating...' : 'Generate Names'}
      </button>

      {results.length > 0 && (
        <div className="w-full max-w-xl bg-gray-900 p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">Results</h2>
          <ul className="list-disc list-inside space-y-2">
            {results.map((r, i) => <li key={i}>{r}</li>)}
          </ul>
        </div>
      )}
    </main>
  );
}