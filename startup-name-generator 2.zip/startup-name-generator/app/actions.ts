"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function generateNames(description: string, tone: string): Promise<string[]> {
  try {
    // Define tone descriptions
    const toneDescriptions = {
      modern: "modern, clean, and minimalist",
      vcbait: "venture capital friendly, innovative, and disruptive",
      gritty: "bold, rugged, and authentic",
      elegant: "sophisticated, refined, and premium",
      techy: "technical, futuristic, and cutting-edge",
      playful: "fun, creative, and approachable",
    }

    // Get the tone description
    const toneDescription = toneDescriptions[tone as keyof typeof toneDescriptions] || toneDescriptions.modern

    // Generate names using AI
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: `You are a startup name generator specialized in creating aesthetic, memorable names.
      
      For each request:
      1. Generate exactly 6 unique startup names based on the description and tone provided
      2. Names should be short (1-2 words), memorable, and brandable
      3. Include a mix of real words, compound words, and made-up words
      4. Focus on names that would work well as domain names
      5. Return ONLY the names as a comma-separated list with no explanations or additional text
      
      Examples of good names: Stripe, Notion, Vercel, Figma, Slack, Airtable, Canva, blvnk, nuvem, GrainWorks`,
      prompt: `Create 6 startup names for a company that does: ${description}. 
      The tone should be: ${toneDescription}.
      Return only the names as a comma-separated list.`,
    })

    // Parse the response and return the names
    const names = text
      .split(",")
      .map((name) => name.trim())
      .filter((name) => name.length > 0)
      .slice(0, 6)

    return names
  } catch (error) {
    console.error("Error generating names:", error)
    return ["Nuvem", "Blvnk", "GrainWorks", "Fluxly", "Zenith", "Quirkle"] // Fallback names
  }
}
